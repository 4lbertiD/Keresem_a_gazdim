<?php 
define('host', 'localhost');
define('user', 'david');
define('pass', 'david');
define('db', 'pets_db');

$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
?>