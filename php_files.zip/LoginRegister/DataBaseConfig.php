<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

    public function __construct()
    {

        $this->servername = 'localhost';
        $this->username = 'david';
        $this->password = 'david';
        $this->databasename = 'pets_db';

    }
}

?>
