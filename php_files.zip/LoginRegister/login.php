<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['username']) && isset($_POST['password'])) {
    if ($db->dbConnect()) {
        if ($db->logIn("users", $_POST['username'], $_POST['password'])) {
            echo "Bejelentkezes sikeres!";
        } else echo "Helytelen jelszo, vagy felhasznalonev";
    } else echo "Error: Database connection";
} else echo "Minden mezo kitoltese szukseges!";
?>
